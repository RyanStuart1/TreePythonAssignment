#!/usr/bin/env python3

import sys # essential library for this script

"""
The purpose of this script is to extract data from a .txt file, trasnform it into the intended output, and load it into a FINAL file with their specific scores.
"""
def import_values(values_file_path):
    """
    import_value function reads the values from the chosen file of values and retuns a dictionary of letters with their values. 
    """
    values = {}
    with open(values_file_path, "r") as v: # reads the values file
        for line in v: # iterates over each line
            parts = line.strip().split() # removes spaces and splits
            if len(parts) == 2: # if there are both a letter and an integer they are stored in a dictionary
                letter, value_str = parts
                values[letter] = int(value_str)
    return values

def scoring_rules(letter, word_index, letter_index, words, values):
    """
    scoring_rules assigns the scoring rules dependent on the letters position within the word that is being abbreviated.
    """
    letter = letter.upper() # CHATGPT debugged issue in points system (returning only position_val) cause by this line
    w = words[word_index]

    if letter_index == 0: # index 0 returns 0 points
        return 0
    elif letter_index == len(w) - 1: # negative index of the word returing 20 points for 20 and 5 for all other letters.
        return 20 if letter == "E" else 5
    
    if letter_index == 1: # index 1 of a word (2nd letter) returns 1 point
        position_val = 1
    elif letter_index == 2: # index 2 of a word (3rd letter) returns 2 points
        position_val = 2
    else:
        position_val = 3 # any other position returns 3 points
    
    value = values.get(letter, 0)
    return position_val + value # each letter returns their score from values dictionary + their positional value from their word.

def abbreviation_score(combined_word, words, values, indices):
    """
    abbreviation_score function produces the net score of each abbreviation.
    """
    index_map = [] # index map which checks for the letter and its position in the word it came from.
    for word_index, w in enumerate(words): # enumerates through each letter and each word.
        for letter_index, _ in enumerate(w):
            index_map.append((word_index, letter_index))
    
    net_score = 0
    for index in indices: # iterates over each index for each abbreviation, locating the letter and its position within each word.
        letter = combined_word[index]
        word_index, letter_index = index_map[index]
        net_score += scoring_rules(letter, word_index, letter_index, words, values) # applies scoring rules
        
    return net_score # returns score for each abbreviation

def abbreviate_data(word):
    """
    Abbreviate_data creates all of the possible abbreviations for each line within the .txt file.
    If the word is 3 letters or less it will return the word on that line.
    """
    if len(word) > 3:
        abbreviations = set()
        for x in range(1, len(word)):
            for y in range(x + 1, len(word)):
                abbreviations.add(word[0] + word[x] + word[y]) # creates abbreviation with first letter of the word followed by 2 additional letters/
        return ' '.join(sorted(abbreviations))
    else:
        return word # less than or equal to three letter returns word
    
def manipulate_data(input_file_path, output_file_path, values): # CHATGPT was used to integrate the scoring system into the manipulate data function. I was able to produce the abbreviations but needed help integrating.
    """                                                         
    The purpose of the manipulate_data function is to read the input file <trees.txt>
    manipulate the words into three letter abbreviations if applicable
    and write the results to <Stuart_trees_abbrevs.txt>.
    """
    try:
        with open(input_file_path, "r") as input_file, open(output_file_path, "w") as output_file: # reads input file, writes to output file
            for line in input_file:
                stripped_line = line.strip().replace("'", "").replace("-", "") # Ignores apostrophes and hyphens
                words = stripped_line.split() # splits each line into words
                if not words: # if there are no words produced then this line is skipped
                    continue

                combined_words = "".join(words) # combines words together
                abbreviation_str = abbreviate_data(combined_words).upper() # creates uppercase abbreviated strings
                abbrev_list = abbreviation_str.split() # splits abbreviations into a list 

                abbrev_indices_map = {}
                if len(combined_words) > 3:
                    for x in range(1, len(combined_words)): # second letter in abbreviation
                        for y in range(x + 1, len(combined_words)): # third letter in abbreviation
                            ab = (combined_words[0] + combined_words[x] + combined_words[y]).upper() # creates abbreviations from first letter and two additional letters for each word/words
                            abbrev_indices_map[ab] = (0, x, y) # stores tuple of indices for abbreviatiom
                else:
                    if abbrev_list:                   # if the word is 3 letters or less then the word is returned ensuring that scoring works effectively.
                        single_abbrev = abbrev_list[0]
                    else:
                        single_abbrev = combined_words.upper()
                    abbrev_indices_map[single_abbrev] = tuple(range(len(combined_words))) # maps single abbreviation to all letter indices of combined words

                scored_abbrevs = []
                for ab in abbrev_list:
                    indices = abbrev_indices_map.get(ab, ()) # gets the indeces for each abbreviation, if it can't the an empty tuple wil be returned
                    score = abbreviation_score(combined_words, words, values, indices) # produces score for each abbreviation based on the rules provided
                    scored_abbrevs.append(f"{ab}({score})") # appends the score to each abbreviation

                output_line = f"{stripped_line} " + ", ".join(scored_abbrevs) # joins stripped line with abbreviations score
                output_file.write(output_line + "\n") # writes the output line to the output file for each Tree on a new line

        print(f"Data transformed and saved to {output_file_path}")
    except Exception as error:
        print(f"An error has occured: {error}") # error handling when creating script
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("main.py <../data/trees.txt> <../output_file> <values_file>")
        sys.exit(1)
    
    input_file_path = sys.argv[1]
    output_file_path = sys.argv[2]
    values_file_path = sys.argv[3]

    values = import_values(values_file_path)

    print(f"{input_file_path} ========> {output_file_path} with their associated values using {values_file_path}")
    manipulate_data(input_file_path, output_file_path, values)
    print(f"Abbreviations saved to {output_file_path}")
